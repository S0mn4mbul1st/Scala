object Lab08 {

  def multiplicate( stf: Stream[Int], num: Stream[Int] ): Stream[Int] = stf match {

    case Stream( hd, t @_* )  => num match {

        case Stream( header, tail @_* ) => looper ( header, hd ) #::: multiplicate ( t.toStream, tail.toStream )

    }
  }

  def looper( n : Int, a : Int ) : Stream[Int] = {

    if( 1 > n )

        Nil.toStream

    else

        a #:: looper( n - 1, a )
  }

  def main(args: Array[String]): Unit = {

    println( multiplicate( Stream(1,2,3), Stream(0,3,1,4) ) )
  }

}
