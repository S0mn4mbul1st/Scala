public class worker{
  
  String position, surname , firstName;

    int salary;

    Employee(String surname, String firstName, int salary) {
      
 	 position="worker";

        this.surname = surname;

        this.firstName = firstName;

        this.salary=salary;
    }

    public String toString() {
     
   return this.firstName + "  " + this.surname + " " + this.salary;
    }

    void increase(int faiz{
      
  this.salary = salary *  ( (100 + faiz) / 100 );
    }
}


class manager{
   
 int bonus;

     manager( String name, String surname, int salary, int bonus) {
     
   super(name, surname,salary);

         type = "Manager";

        this.bonus = bonus;
    }

    void giveBonus(int bonus){    this.bonus=bonus;  }

    public String toString() {

        return this.firstName + " " + this.surname + "  " + this.salary + " " + bonus;
    }
}