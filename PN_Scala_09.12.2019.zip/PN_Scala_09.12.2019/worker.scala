class worker (var pos: String,  var name: String, var surname: String, var  salary: Int){

  def bonus(a: Int):Unit ={ this.salary = salary * ( 100 + a ) /100 }

  override def toString(): String =  {
    name +" "+ surname + "  " + salary } }


class sEmployee (var Spos: String,  sname: String, Ssurname: String,specSalary: Int,  var ssalary: Int) extends Employee(var pos: String,  var name: String, var surname: String, var  salary: Int) {

  override def toString():String = {
    sname +" "+ surname + " " + salary + " " + ssalary
  }
  def giveBonus(bonus: Int):Unit ={ this.bonus=bonus}
}
