
import java.util.LinkedList;

public class startUp {
  
  LinkedList<worker> workers= new LinkedList<>();

  LinkedList<manager> Specworkers= new LinkedList<>();

    public void addworker( String name, String surname, int salary){
      
  worker a = new worker( name,surname, salary);

         workers.add(a);
    }

    public void addSpecworker(  String name,String surname, int salary, int bonus){

        manager a = new manager( name, surname, salary, bonus);

         workers.add(a);

         Specworkers.add(a);
    }

    public String toString(){
    
        for (worker allworker : allworkers) 

            System.out.println(allworker);
        
        return "\n";
    }

    public void increaseSalaries(int a){

        for (worker allworker : allworkers) 

            allworker.increase(a);
        
    }

 
   public void giveBonus(int bonus){

        System.out.println("BONUS GRANTED FOR ALL SPECIALISTS: "+bonus+"$");

        for (manager allSpecworker : allSpecworkers) 

            allSpecworker.giveBonus(bonus);
        
        for(int j = allworkers.size(); 0 < j; j--)

            if(allworkers.get(j - 1).type.equals("Manager") ) {

                allworkers.remove(j - 1);
            
        }
     
   allworkers.addAll(allSpecworkers);
    }

    public static void main(String[] args) {
      

    }
}