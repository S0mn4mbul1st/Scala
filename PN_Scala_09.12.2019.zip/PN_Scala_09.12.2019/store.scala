import scala.collection.mutable.ListBuffer

class StartUp {
  
  var hamsi: ListBuffer[] = ListBuffer[worker]()
  
  var managers: ListBuffer[sworker] = ListBuffer[sworker]()

  def ad(surname: String, name: String, salary: Int): ListBuffer[worker] = {
    
      val a = new worker("Worker", surname, name, salary)
    
      hamsi += a
    }

  def addManager(name: String, surname: String, salary: Int, bonus: Int): Unit ={
   
    val b = new sworker("Manager ", name,surname, salary, bonus)
  
    hamsi += b
  
    managers += b
  }

def zam(faiz: Int):Unit = {
 
  def increaseSal( per: Int, list: ListBuffer[worker]): ListBuffer[worker] = {
 
    if (list.isEmpty)   return ListBuffer[worker]()
 
    list.head.increase(per)
 
    increaseSal(per, list.tail)
  }
  
  increaseSal(faiz,hamsi)
}

  override def toString():String ={ printhamsi(hamsi.toList).toString() }

  def printhamsi(empToPrint: List[worker]):List[worker] = {
    
    if(empToPrint.isEmpty)    return Nil
    
    println(empToPrint.head)

    printhamsi(empToPrint.tail)
  }
}
