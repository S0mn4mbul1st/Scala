object main {

  val even = nn filter (_ % 2 == 0)
  println(even.take(10).mkString(","))

}
